/* The Testing Academy — shared shell behaviour
   ---------------------------------------------
   Wires up:
   - Theme toggle (light <-> dark) with localStorage persistence.
   - Sidebar collapse (desktop) + mobile drawer.
   - Active nav link highlight based on current path.
   - Optional dashboard card search filter (when a [data-card-search] input exists).

   Theme attribute is hydrated synchronously in each page <head>
   before this file loads, so we never flash the wrong theme.        */

(function () {
  "use strict";

  var STORAGE_KEY = "tta-theme";
  var SIDEBAR_KEY = "tta-sidebar-collapsed";
  var root = document.documentElement;

  // ---- Theme toggle ----
  function applyTheme(theme) {
    root.setAttribute("data-theme", theme === "dark" ? "dark" : "light");
    try {
      window.localStorage.setItem(STORAGE_KEY, theme);
    } catch (e) {
      /* ignore storage errors (e.g. private mode) */
    }
  }

  function currentTheme() {
    return root.getAttribute("data-theme") === "dark" ? "dark" : "light";
  }

  function toggleTheme() {
    applyTheme(currentTheme() === "dark" ? "light" : "dark");
  }

  // ---- Sidebar collapse / mobile drawer ----
  function shellEl() {
    return document.querySelector(".tta-shell");
  }

  function setSidebarCollapsed(collapsed) {
    var shell = shellEl();
    if (!shell) return;
    if (collapsed) {
      shell.setAttribute("data-sidebar-collapsed", "true");
    } else {
      shell.removeAttribute("data-sidebar-collapsed");
    }
    try {
      window.localStorage.setItem(SIDEBAR_KEY, collapsed ? "1" : "0");
    } catch (e) {
      /* ignore */
    }
  }

  function toggleSidebar() {
    var shell = shellEl();
    if (!shell) return;
    var isMobile = window.matchMedia("(max-width: 1023px)").matches;
    if (isMobile) {
      var open = shell.getAttribute("data-mobile-open") === "true";
      if (open) {
        shell.removeAttribute("data-mobile-open");
      } else {
        shell.setAttribute("data-mobile-open", "true");
      }
    } else {
      var collapsed = shell.getAttribute("data-sidebar-collapsed") === "true";
      setSidebarCollapsed(!collapsed);
    }
  }

  function closeMobileDrawer() {
    var shell = shellEl();
    if (shell) shell.removeAttribute("data-mobile-open");
  }

  // ---- Sidebar nav icons (hydrated client-side, keeps each HTML page small) ----
  var SVG_NS = "http://www.w3.org/2000/svg";
  var ICON_PATHS = {
    "Overview": '<path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
    "Multiple Element Filter": '<path d="M3 3l7.5 18.5L13 13l8.5-2.5z"/><path d="m13 13 6 6"/>',
    "Web Table Directory": '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
    "QA Profile Form": '<rect x="8" y="2" width="8" height="4" rx="1" ry="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="M9 12h6"/><path d="M9 16h6"/>',
    "Companies Table": '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 9v12"/>',
    "Tall Buildings Table": '<path d="M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z"/><path d="M6 12H2"/><path d="M22 12h-4"/><path d="M10 7h2"/><path d="M10 11h2"/><path d="M10 15h2"/>',
    "Custom Dropdowns": '<rect x="3" y="6" width="18" height="13" rx="2"/><polyline points="8 11 12 15 16 11"/>',
    "Select Box Variants": '<path d="M20.59 13.41 13 21l-9-9V4h8z"/><circle cx="7.5" cy="7.5" r="1.5"/>',
    "Frames overview": '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18"/>',
    "Multi-frame frameset": '<rect x="3" y="3" width="8" height="8"/><rect x="13" y="3" width="8" height="8"/><rect x="3" y="13" width="8" height="8"/><rect x="13" y="13" width="8" height="8"/>',
    "Nested iframes": '<rect x="3" y="3" width="18" height="18" rx="2"/><rect x="6" y="6" width="12" height="12" rx="1.5"/><rect x="9" y="9" width="6" height="6" rx="1"/>',
    "Alerts & Modals": '<path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
    "Windows & Tabs": '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18"/><path d="M9 9v12"/>',
    "Upload & Download": '<path d="M12 3v12"/><path d="m6 9 6-6 6 6"/><path d="M21 15v6H3v-6"/>',

    // Tools
    "SnapLocator (Chrome ext)": '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>',

    // Projects
    "TTACart demo":      '<circle cx="9" cy="21" r="1.5"/><circle cx="18" cy="21" r="1.5"/><path d="M3 3h2l2.4 12.4a2 2 0 0 0 2 1.6h8.7a2 2 0 0 0 2-1.6L22 8H6"/>',
    "TTAStays booking":  '<path d="M2 17h20"/><path d="M2 12h20"/><path d="M2 12V7a2 2 0 0 1 2-2h6v7"/><path d="M22 12V7a2 2 0 0 0-2-2h-6v7"/><path d="M2 17v4"/><path d="M22 17v4"/>',
    "TTA AI Chat":       '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/><circle cx="9" cy="10" r="1"/><circle cx="13" cy="10" r="1"/><circle cx="17" cy="10" r="1"/>',

    // Tables & Forms (extras)
    "Sortable Admin Table": '<path d="M3 6h18M3 12h18M3 18h18"/><polyline points="7 4 4 7 7 10"/><polyline points="17 14 20 17 17 20"/>',
    "Cricket Scorecard":    '<circle cx="12" cy="12" r="9"/><path d="m9 12 2 2 4-4"/>',

    // Frames (extras)
    "Courses frameset": '<path d="M4 19V5a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v14l-7-4-7 4z"/>',

    // Widgets
    "SVG locators":          '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/>',
    "Shadow DOM":            '<path d="M9 2a9 9 0 1 0 12 12A7 7 0 0 1 9 2z"/>',
    "Calendar / date picker":'<rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>',
    "Drag & drop Kanban":    '<circle cx="9" cy="6" r="1"/><circle cx="9" cy="12" r="1"/><circle cx="9" cy="18" r="1"/><circle cx="15" cy="6" r="1"/><circle cx="15" cy="12" r="1"/><circle cx="15" cy="18" r="1"/>',
    "Toasts & notifications":'<path d="M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>',
    "Native dialogs":        '<circle cx="12" cy="12" r="9"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>',
    "Hover menus":           '<path d="M3 3l7.5 18.5L13 13l8.5-2.5z"/>',
    "Right-click menu":      '<rect x="6" y="3" width="12" height="18" rx="6"/><line x1="12" y1="7" x2="12" y2="11"/>',
    "Keyboard navigation":   '<rect x="2" y="6" width="20" height="12" rx="2"/><path d="M6 10h.01M10 10h.01M14 10h.01M18 10h.01M6 14h12"/>',
    "Scroll":                '<path d="M12 5v14"/><polyline points="6 11 12 5 18 11"/><polyline points="6 19 12 13 18 19"/>',
    "Assertions (expect)":   '<polyline points="20 6 9 17 4 12"/>',
    "Test modifiers · hooks · data": '<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><path d="m14 18 3 3 4-5"/>',
    "Data-driven + POM":     '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v6c0 1.7 4 3 9 3s9-1.3 9-3V5"/><path d="M3 11v6c0 1.7 4 3 9 3s9-1.3 9-3v-6"/>',

    // JavaScript notes
    "JS notes": '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><path d="M9 13h6M9 17h6"/>',

    // Frameworks
    "Advance Playwright framework": '<path d="M12 2 4 6v6c0 5 3.5 9 8 10 4.5-1 8-5 8-10V6z"/><path d="m9 12 2 2 4-4"/>',
    "Framework":                    '<path d="M12 2 4 6v6c0 5 3.5 9 8 10 4.5-1 8-5 8-10V6z"/><path d="m9 12 2 2 4-4"/>',
    "Framework + AI":               '<path d="M12 2 4 6v6c0 5 3.5 9 8 10 4.5-1 8-5 8-10V6z"/><path d="M9 11l1.5 1.5L9 14l-1.5-1.5z" fill="currentColor"/><path d="M15 9l1 1-1 1-1-1z" fill="currentColor"/><circle cx="12" cy="13" r="1" fill="currentColor"/>',

    // Network
    "Network interception": '<path d="M3 12h4l3 9 4-18 3 9h4"/>'
  };

  function buildIcon(name) {
    var paths = ICON_PATHS[name];
    if (!paths) return null;
    var wrap = document.createElement("span");
    wrap.innerHTML = '<svg xmlns="' + SVG_NS + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + paths + '</svg>';
    return wrap.firstChild;
  }

  function hydrateNavIcons() {
    var links = document.querySelectorAll(".tta-sidebar-nav .tta-nav-link");
    links.forEach(function (link) {
      var dot = link.querySelector(".nav-dot");
      if (!dot || dot.firstChild) return;
      var label = link.querySelector("span:not(.nav-dot):not(.nav-tag)");
      var name = label ? (label.textContent || "").trim() : "";
      var svg = buildIcon(name);
      if (svg) dot.appendChild(svg);
    });
  }

  // ---- Active nav link ----
  function highlightActiveLink() {
    var path = window.location.pathname.split("/").pop() || "index.html";
    var links = document.querySelectorAll(".tta-sidebar-nav a[href]");
    links.forEach(function (link) {
      var href = link.getAttribute("href") || "";
      var target = href.split("#")[0].split("/").pop();
      if (!target) return;
      if (target === path) {
        link.setAttribute("aria-current", "page");
      }
    });
  }

  // ---- Dashboard card search ----
  function bindCardSearch() {
    var input = document.querySelector("[data-card-search]");
    if (!input) return;
    var cards = Array.prototype.slice.call(
      document.querySelectorAll("[data-card]")
    );
    if (!cards.length) return;

    function applyFilter() {
      var q = (input.value || "").trim().toLowerCase();
      cards.forEach(function (card) {
        var hay = (card.getAttribute("data-card") || card.textContent || "")
          .toLowerCase();
        card.style.display = !q || hay.indexOf(q) !== -1 ? "" : "none";
      });
    }

    input.addEventListener("input", applyFilter);
  }

  // ---- Locator marking toggle ----
  var MARKS_KEY = "tta-marks";

  function applyMarks(on) {
    document.body.setAttribute("data-marks", on ? "on" : "off");
    try {
      window.localStorage.setItem(MARKS_KEY, on ? "1" : "0");
    } catch (e) {
      /* ignore */
    }
    document
      .querySelectorAll("[data-mark-toggle] input")
      .forEach(function (cb) {
        cb.checked = on;
      });
  }

  function bindMarkToggle() {
    var stored = null;
    try {
      stored = window.localStorage.getItem(MARKS_KEY);
    } catch (e) {
      /* ignore */
    }
    var on = stored === null ? true : stored === "1";
    applyMarks(on);

    document
      .querySelectorAll("[data-mark-toggle] input")
      .forEach(function (cb) {
        cb.addEventListener("change", function () {
          applyMarks(cb.checked);
        });
      });
  }

  // ---- Wire up listeners ----
  function init() {
    // Sidebar default state on desktop: respect storage.
    var shell = shellEl();
    if (shell && window.matchMedia("(min-width: 1024px)").matches) {
      var stored = null;
      try {
        stored = window.localStorage.getItem(SIDEBAR_KEY);
      } catch (e) {
        /* ignore */
      }
      if (stored === "1") shell.setAttribute("data-sidebar-collapsed", "true");
    }

    // Theme toggle buttons (sidebar foot + topbar)
    document
      .querySelectorAll("[data-theme-toggle]")
      .forEach(function (btn) {
        btn.addEventListener("click", toggleTheme);
      });

    // Sidebar/mobile toggle buttons
    document
      .querySelectorAll("[data-sidebar-toggle]")
      .forEach(function (btn) {
        btn.addEventListener("click", toggleSidebar);
      });

    // Backdrop click closes the mobile drawer
    document
      .querySelectorAll("[data-mobile-close]")
      .forEach(function (el) {
        el.addEventListener("click", closeMobileDrawer);
      });

    // Close mobile drawer when a sidebar link is clicked.
    document
      .querySelectorAll(".tta-sidebar-nav a[href]")
      .forEach(function (a) {
        a.addEventListener("click", function () {
          if (window.matchMedia("(max-width: 1023px)").matches) {
            closeMobileDrawer();
          }
        });
      });

    hydrateNavIcons();
    highlightActiveLink();
    bindCardSearch();
    bindMarkToggle();
    bindTabs();
    bindNavSectionCollapse();
    injectPromoBanner();
  }

  // ---- Global promo banner (AI Tester Blueprint launch) ----
  function injectPromoBanner() {
    var DISMISS_KEY = "tta-promo-banner-dismissed";
    try {
      if (window.localStorage.getItem(DISMISS_KEY) === "1") return;
    } catch (e) { /* ignore */ }

    if (document.querySelector(".tta-promo-banner")) return;

    var banner = document.createElement("div");
    banner.className = "tta-promo-banner";
    banner.setAttribute("role", "region");
    banner.setAttribute("aria-label", "Announcement: AI Tester Blueprint new batch");
    banner.innerHTML = ''
      + '<span class="promo-live"><span class="promo-dot"></span>LIVE</span>'
      + '<span class="promo-title">AI Tester Blueprint</span>'
      + '<span class="promo-badge">New batch</span>'
      + '<span class="promo-sep">|</span>'
      + '<span class="promo-when">23 May 2026 &middot; 11:00 AM IST</span>'
      + '<span class="promo-sep">|</span>'
      + '<span class="promo-price"><s>&#8377;35,000</s><b>&#8377;9,999</b><em>33% OFF</em></span>'
      + '<span class="promo-coupon">Code <code>AITESTER</code></span>'
      + '<a class="promo-cta" href="https://bit.ly/aitester2026" target="_blank" rel="noopener">Join</a>'
      + '<a class="promo-wa" href="https://sdet.live/WhatsApp" target="_blank" rel="noopener" aria-label="Chat on WhatsApp">&#9742;</a>'
      + '<button type="button" class="promo-close" aria-label="Dismiss banner">&times;</button>';

    document.body.insertBefore(banner, document.body.firstChild);
    document.body.setAttribute("data-banner", "on");

    var closeBtn = banner.querySelector(".promo-close");
    if (closeBtn) {
      closeBtn.addEventListener("click", function () {
        banner.remove();
        document.body.removeAttribute("data-banner");
        try { window.localStorage.setItem(DISMISS_KEY, "1"); } catch (e) { /* ignore */ }
      });
    }
  }

  // ---- Sidebar nav-section collapse (per-section, persisted) ----
  function navSectionKey(section) {
    var title = section.querySelector(".tta-nav-section-title");
    if (!title) return null;
    var label = (title.textContent || "").trim().toLowerCase()
      .replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
    return "tta-nav-section:" + (label || "unknown");
  }

  function bindNavSectionCollapse() {
    var sections = document.querySelectorAll(".tta-sidebar-nav .tta-nav-section");
    sections.forEach(function (section) {
      var title = section.querySelector(".tta-nav-section-title");
      var list = section.querySelector(".tta-nav-list");
      if (!title || !list) return;

      // Add chevron if missing.
      if (!title.querySelector(".section-chevron")) {
        var chev = document.createElementNS(SVG_NS, "svg");
        chev.setAttribute("class", "section-chevron");
        chev.setAttribute("viewBox", "0 0 24 24");
        chev.setAttribute("fill", "none");
        chev.setAttribute("stroke", "currentColor");
        chev.setAttribute("stroke-width", "2.4");
        chev.setAttribute("stroke-linecap", "round");
        chev.setAttribute("stroke-linejoin", "round");
        chev.setAttribute("aria-hidden", "true");
        var path = document.createElementNS(SVG_NS, "path");
        path.setAttribute("d", "m6 9 6 6 6-6");
        chev.appendChild(path);
        title.appendChild(chev);
      }

      // Make title an accessible button.
      title.setAttribute("role", "button");
      title.setAttribute("tabindex", "0");
      title.setAttribute("aria-expanded", "true");

      // Hydrate from localStorage.
      var key = navSectionKey(section);
      var stored = null;
      try { stored = key ? window.localStorage.getItem(key) : null; } catch (e) { /* ignore */ }

      // Keep section open if it contains the active link, regardless of stored state.
      var hasActive = !!section.querySelector('.tta-nav-link[aria-current="page"], .tta-nav-link.is-active');
      var shouldCollapse = stored === "1" && !hasActive;
      if (shouldCollapse) {
        section.setAttribute("data-collapsed", "true");
        title.setAttribute("aria-expanded", "false");
      }

      function toggle() {
        var collapsed = section.getAttribute("data-collapsed") === "true";
        if (collapsed) {
          section.removeAttribute("data-collapsed");
          title.setAttribute("aria-expanded", "true");
        } else {
          section.setAttribute("data-collapsed", "true");
          title.setAttribute("aria-expanded", "false");
        }
        try {
          if (key) window.localStorage.setItem(key, collapsed ? "0" : "1");
        } catch (e) { /* ignore */ }
      }

      title.addEventListener("click", toggle);
      title.addEventListener("keydown", function (e) {
        if (e.key === "Enter" || e.key === " " || e.key === "Spacebar") {
          e.preventDefault();
          toggle();
        }
      });
    });
  }

  // ---- Page tabs (Page / Practice / Solution) ----
  function bindTabs() {
    document.querySelectorAll('[role="tablist"].tta-tabs').forEach(function (list) {
      var tabs = Array.prototype.slice.call(list.querySelectorAll('[role="tab"]'));
      if (!tabs.length) return;

      function selectTab(tab, focus) {
        tabs.forEach(function (t) {
          var isMe = t === tab;
          t.setAttribute("aria-selected", isMe ? "true" : "false");
          t.tabIndex = isMe ? 0 : -1;
          var panelId = t.getAttribute("aria-controls");
          var panel = panelId && document.getElementById(panelId);
          if (panel) {
            if (isMe) panel.removeAttribute("hidden");
            else panel.setAttribute("hidden", "");
          }
        });
        if (focus) tab.focus();
        var key = tab.dataset.testid || tab.id || "";
        if (key && history && history.replaceState) {
          var hash = key.replace(/^tab-/, "");
          if (hash) history.replaceState(null, "", "#" + hash);
        }
      }

      // Initial selection — honour URL hash if it matches one of the tabs.
      var hash = window.location.hash.replace(/^#/, "");
      var initial = null;
      if (hash) {
        initial = tabs.find(function (t) {
          return (t.dataset.testid || "").replace(/^tab-/, "") === hash;
        });
      }
      if (!initial) initial = tabs.find(function (t) { return t.getAttribute("aria-selected") === "true"; }) || tabs[0];
      selectTab(initial, false);

      tabs.forEach(function (tab) {
        tab.addEventListener("click", function () { selectTab(tab, false); });
        tab.addEventListener("keydown", function (event) {
          var idx = tabs.indexOf(tab);
          if (event.key === "ArrowRight") { selectTab(tabs[(idx + 1) % tabs.length], true); event.preventDefault(); }
          else if (event.key === "ArrowLeft") { selectTab(tabs[(idx - 1 + tabs.length) % tabs.length], true); event.preventDefault(); }
          else if (event.key === "Home") { selectTab(tabs[0], true); event.preventDefault(); }
          else if (event.key === "End") { selectTab(tabs[tabs.length - 1], true); event.preventDefault(); }
        });
      });
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
